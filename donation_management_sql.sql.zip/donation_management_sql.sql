-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2025 at 07:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donation_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
CREATE TABLE IF NOT EXISTS `album` (
  `album_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `target_amount` decimal(10,2) DEFAULT NULL,
  `current_amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('Active','Completed','Cancelled') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`album_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

DROP TABLE IF EXISTS `donor`;
CREATE TABLE IF NOT EXISTS `donor` (
  `donor_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(25) NOT NULL,
  `pin_code` varchar(10) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `profile_img` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`donor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`donor_id`, `name`, `address`, `city`, `pin_code`, `email_id`, `password`, `contact_no`, `profile_img`, `status`) VALUES
(1, 'Swathi', 'No. 12, Jalan SS2/24, 47300 Petaling Jaya, Selangor Darul Ehsan.', 'Petaling Jaya, Selangor', '47300', 'swathi@gmail.com', '12345678', '0112345678', 'Sandip_pic.png', 'Active'),
(2, 'Sharun Dsouza', 'Lot 24, Jalan Damai, 88300 Kota Kinabalu, Sabah', 'Kota Kinabalu, Sabah', '88300', 'sharundsouza@gmail.com', '111111', '0115846125', 'phani_pic11.jpg', 'Active'),
(3, 'Soumya Salian', '45, Jalan Free School, 11600 George Town, Pulau Pinang.', 'George Town, Penang', '11600', 'soumyasalian@gmail.com', '987654321', '0165943310', 'Passport_Size_Image_of_Nouman.jpg', 'Active'),
(4, 'Sudhir kumar', 'No. 7, Jalan Indah 15/2, Taman Bukit Indah, 81200 Johor Bahru, Johor Darul Takzim.', 'Johor Bahru, Johor', '81200', 'sudhirkumar@gmail.com', '123456789', '0173321784', 'c53aa684465bc61455fd0d21537752fb.jpg', 'Active'),
(5, 'c', '', '', '', 'c@gmail.com', 'abc123', '0123456789', '', 'Active'),
(6, 'Aiman Hakim', '32, Lorong Bukit Setongkol 48, Taman Bukit Setongkol, 25200 Kuantan, Pahang Darul Makmur.', 'Kuantan, Pahang', '25200', 'aimanhakim89@gmail.com', 'Aiman', '0134567892', '', 'Active'),
(7, 'Farhan Bin Zulkifli', '', '', '', 'farhan.zul92@gmail.com', 'Farham', '0123948271', '', 'Active'),
(8, 'Nurul Syafiqa Binti Mohd Amin', '', '', '', 'syafiqa.amin27@gmail.com', 'Syafiqa', '0176639210', '', 'Active'),
(9, 'Aisyah Binti Roslan', '', '', '', 'aisyah.roslan77@gmail.com', 'aisyah', '0147810234', '', 'Active'),
(32, 'Lily', '', '', '', 'lily@gmail.com', 'lily', '0165482344', '', 'Active'),
(33, 'chin', '', '', '', 'c@gmail.com', 'abc123', '0123456789', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `fund_collection`
--

DROP TABLE IF EXISTS `fund_collection`;
CREATE TABLE IF NOT EXISTS `fund_collection` (
  `fund_collection_id` int(10) NOT NULL AUTO_INCREMENT,
  `fund_raiser_id` int(10) NOT NULL,
  `donor_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `paid_amt` decimal(10,2) DEFAULT NULL,
  `paid_date` date NOT NULL,
  `payment_type` varchar(25) NOT NULL,
  `payment_detail` text NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`fund_collection_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `fund_collection`
--

INSERT INTO `fund_collection` (`fund_collection_id`, `fund_raiser_id`, `donor_id`, `name`, `paid_amt`, `paid_date`, `payment_type`, `payment_detail`, `status`) VALUES
(17, 8, 13, 'Srujan gowda', 100.00, '2020-02-27', 'MASTER CARD', 'a:4:{i:0;s:9:\"Raj kiran\";i:1;s:16:\"1234567890123456\";i:2;s:7:\"2022-01\";i:3;s:3:\"485\";}', 'Active'),
(18, 5, 12, 'pooja', 2500.00, '2020-02-27', 'MASTER CARD', 'a:4:{i:0;s:17:\"12345678901345687\";i:1;s:16:\"1234567890132456\";i:2;s:7:\"2021-01\";i:3;s:3:\"154\";}', 'Active'),
(19, 3, 14, 'Prathima', 25000.00, '2020-03-04', 'VISA', 'a:4:{i:0;s:9:\"Raj kiran\";i:1;s:16:\"1253456789012345\";i:2;s:7:\"2021-01\";i:3;s:3:\"458\";}', 'Active'),
(20, 8, 3, 'Akshatha', 35000.00, '2020-03-05', 'VISA', 'a:4:{i:0;s:9:\"Raj kiran\";i:1;s:16:\"1234567890123456\";i:2;s:7:\"2021-01\";i:3;s:3:\"598\";}', 'Active'),
(21, 8, 3, 'sharath kumar', 2500.00, '2020-03-16', 'VISA', 'a:4:{i:0;s:17:\"Sharath A N Kumar\";i:1;s:16:\"9934567890123456\";i:2;s:7:\"2021-01\";i:3;s:3:\"589\";}', 'Active'),
(22, 10, 11, 'Swathi', 250.00, '2020-08-26', 'VISA', 'a:4:{i:0;s:3:\"Raj\";i:1;s:16:\"1234567890123456\";i:2;s:7:\"2021-02\";i:3;s:3:\"158\";}', 'Active'),
(24, 8, 1, 'Swathi', 45000.00, '2025-06-15', 'VISA', 'a:4:{i:0;s:6:\"Swathi\";i:1;s:16:\"1234123412341234\";i:2;s:7:\"2027-01\";i:3;s:3:\"123\";}', 'Active'),
(25, 9, 16, 'Aiman Hakim', 110000.00, '2025-06-15', 'VISA', 'a:4:{i:0;s:5:\"Aiman\";i:1;s:16:\"9876987698769876\";i:2;s:7:\"2027-07\";i:3;s:3:\"147\";}', 'Active'),
(26, 12, 17, 'Farhan Bin Zulkifli', 500.00, '2025-06-15', 'MASTER CARD', 'a:4:{i:0;s:6:\"Farhan\";i:1;s:9:\"123456789\";i:2;s:7:\"2026-06\";i:3;s:3:\"789\";}', 'Active'),
(27, 13, 1, 'Swathi', 100000.00, '2025-06-15', 'VISA', 'a:4:{i:0;s:6:\"Swathi\";i:1;s:16:\"1234567891234567\";i:2;s:7:\"2026-12\";i:3;s:3:\"654\";}', 'Active'),
(28, 12, 13, 'Sudhir kumar', 60000.00, '2025-06-15', 'MASTER CARD', 'a:4:{i:0;s:6:\"Sudhir\";i:1;s:16:\"1234567893216549\";i:2;s:7:\"2026-10\";i:3;s:3:\"651\";}', 'Active'),
(29, 8, 10, 'Sharun Dsouza', 500.00, '2025-06-15', 'MASTER CARD', 'a:4:{i:0;s:6:\"Sharun\";i:1;s:16:\"9874845678941245\";i:2;s:7:\"2026-08\";i:3;s:3:\"658\";}', 'Active'),
(30, 30, 1, 'Swathi', 500.00, '2025-06-17', 'VISA', 'a:4:{i:0;s:6:\"Swathi\";i:1;s:16:\"7889546123554816\";i:2;s:7:\"2030-02\";i:3;s:3:\"951\";}', 'Active'),
(31, 9, 1, 'Swathi', 1020.00, '2025-06-24', 'MASTER CARD', 'a:4:{i:0;s:6:\"Swathi\";i:1;s:16:\"1234156415871547\";i:2;s:7:\"2025-11\";i:3;s:3:\"124\";}', 'Active'),
(32, 8, 1, 'Swathi', 1000.00, '2025-06-25', 'VISA', 'a:4:{i:0;s:1:\"c\";i:1;s:16:\"1234123412341234\";i:2;s:7:\"2025-01\";i:3;s:3:\"123\";}', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `fund_raiser`
--

DROP TABLE IF EXISTS `fund_raiser`;
CREATE TABLE IF NOT EXISTS `fund_raiser` (
  `fund_raiser_id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `banner_img` varchar(100) NOT NULL,
  `fund_raiser_description` text NOT NULL,
  `fund_amount` float(10,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`fund_raiser_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `fund_raiser`
--

INSERT INTO `fund_raiser` (`fund_raiser_id`, `title`, `banner_img`, `fund_raiser_description`, `fund_amount`, `start_date`, `end_date`, `status`) VALUES
(8, 'Sponsor Education & Food of Orphan Children in India\r\n', 'Orphan_Children.jpg', 'This orphanage home aims to provide care, support and protection for 50 orphan & street children. This home has 6 Care Takers, One Teacher. All the orphan children are being provided with 3 times nutritious food, one set of books and 4 sets of uniforms. Every child has opportunity for indoor and out-door recreation and play facilities along with training in crafts and hobbies. All orphan children goes to school every day & progressing good in their studies. Children are studying from I to XII Std', 240000.00, '2020-02-20', '2021-03-16', 'Active'),
(9, 'Help provide basic amenities', 'amenities.jpg', 'The Becoming I Foundation - VIT chapter is a Non-Governmental Organization of roughly 200 students from Vellore Institute of Technology, Vellore, Tamil Nadu. We believe that education is at the forefront of creating productive change and ensuring wellness for our society. Our aim is to contribute, to the best of our abilities, by teaching English and Mathematics to the children of government schools in and around Vellore. Additionally, we provide peer support to children who have been diagnosed with cancer. In doing this, we hope to not only influence the lives of the lesser privileged, but also encourage our fellow peers to realize that change starts with themselves.\r\n\r\nWe aim to make sure that education is within the reach of everyone we can help by making it accessible to them. The best part is that we get to have fun while doing so!\r\n\r\nBIF has organized various events and sessions thoroughout its run, such as\r\nteaching sessions in nearby cancer care centers, government and tribal schools consisting of 4 sessions every week, on-campus events for the school kids and their families - the most popular one being \"Smile\" and \"Umang\", and providing our services and support, just to name a few.\r\n\r\nTo maintain this successful run, we require contributions from your end, and together, we at BIF can continue to shine our light and help out those in need.\r\nDetails for direct bank transfer / UPI', 200000.00, '2020-02-29', '2021-03-01', 'Active'),
(12, 'Help The People Of Backward Areas To Rise From Extreme Poverty', 'area.jpg', 'There are nearly 109 districts in India which are backward and underdeveloped. We have started our journey from Bundelkhand region as this region tops among the list. Project Srishtipath aims to develop all these areas by providing them with a self-sustaining model. One campaign is for a single area as we will be covering all the 109 districts in 109 Phases. This is phase 1 of Project Srishtipath. ', 250000.00, '2020-03-04', '2020-11-19', 'Active'),
(13, 'Funds Required For Orphanage Kids For School Books And Supplies', 'boks.jpg', '•Trustees / Management of orphanage arrange funds  for school supplies through their Own funds or Donations from other donors.\r\n•It puts burden on their finances.\r\n• Sometimes Old books / used school bags / dresses are used by orphanage kids.', 550000.00, '2020-03-04', '2021-11-19', 'Active'),
(30, 'Fundraising to Help Orphans', '1027620964orphanage.jpg', '<div data-start=\"210\" data-end=\"505\">Every child deserves the chance to thrive. This fundraiser is dedicated to supporting orphans by providing access to essential resources such as basic amenities, inclusive education and therapy services.</div>\r\n<div data-start=\"507\" data-end=\"819\">Your support will help create a more inclusive world where these children are empowered to reach their full potential and feel seen, valued and celebrated. Every donation, no matter the size, brings us closer to removing barriers and building a future filled with hope, dignity, and opportunity for every child.</div>\r\n<div data-start=\"821\" data-end=\"892\">Join us in making a lasting impact. Together, we can be the difference.</div>', 50000.00, '2025-06-15', '2025-08-03', 'Active'),
(31, 'Helping Flood Victims', '541354938mktg_1456740369.jpg', '<p>There has been a heavy flood happening and many has lost their home and belongings. Help us secure enough funds to help them get back on their feet and provide them with necessities.</p>', 100000.00, '2025-06-21', '2025-07-11', 'Active'),
(32, 'asd', '6184535501027620964orphanage.jpg', '<p>asdddd</p>', 10000.00, '2025-06-28', '2025-07-26', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_id` int(11) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `item_condition` enum('New','Like New','Good','Fair','Poor') NOT NULL,
  `status` enum('Pending','Available','Rejected','Claimed','Deleted') NOT NULL DEFAULT 'Pending',
  `date_added` datetime DEFAULT current_timestamp(),
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `donor_id` (`donor_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `donor_id`, `address`, `city`, `category_id`, `item_name`, `description`, `quantity`, `item_condition`, `status`, `date_added`, `image_path`) VALUES
(7, 1, 'somewhere', 'Petaling Jaya, Selangor', 8, 'Clothing', 'Rarely worn clothes.', 7, 'Like New', 'Deleted', '2025-06-16 10:38:26', 'uploads/items/item_684fd80273de55.09383764.png'),
(9, 1, 'ty', 'Petaling Jaya, Selangor', 9, 'Books', 'test', 9, 'Like New', 'Available', '2025-06-17 19:10:07', 'uploads/items/item_6851a16f69b816.60642569.jpg'),
(10, 1, 'where', 'Petaling Jaya, Selangor', 8, 'Women\'s clothing', 'new ish', 11, 'Like New', 'Rejected', '2025-06-17 19:18:40', 'uploads/items/item_6851a370a16711.50184420.png'),
(11, 1, 'jalan abc', 'cyberjaya', 9, 'Books', 'adadadfs', 1, 'Good', 'Pending', '2025-06-25 10:18:46', 'uploads/items/item_685bb0e61ec265.18107976.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `item_categories`
--

DROP TABLE IF EXISTS `item_categories`;
CREATE TABLE IF NOT EXISTS `item_categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_categories`
--

INSERT INTO `item_categories` (`category_id`, `category_name`, `description`, `date_created`, `is_active`) VALUES
(8, 'Clothing', NULL, '2025-06-18 05:27:11', 1),
(9, 'Books', NULL, '2025-06-18 05:27:11', 1),
(10, 'Electronics', NULL, '2025-06-18 05:27:11', 1),
(11, 'Furniture', NULL, '2025-06-18 05:27:11', 1),
(12, 'Kitchenware', NULL, '2025-06-18 05:27:11', 1),
(13, 'Toys', NULL, '2025-06-18 05:27:11', 1),
(14, 'Other', NULL, '2025-06-18 05:27:11', 1);

-- --------------------------------------------------------

--
-- Table structure for table `item_requests`
--

DROP TABLE IF EXISTS `item_requests`;
CREATE TABLE IF NOT EXISTS `item_requests` (
  `request_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `requested_quantity` int(11) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` datetime NOT NULL,
  `processed_date` datetime DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`request_id`),
  KEY `item_id` (`item_id`),
  KEY `receiver_id` (`receiver_id`),
  KEY `processed_by` (`processed_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_requests`
--

INSERT INTO `item_requests` (`request_id`, `item_id`, `receiver_id`, `requested_quantity`, `status`, `request_date`, `processed_date`, `processed_by`) VALUES
(1, 9, 2, 1, 'Approved', '2025-06-18 05:22:45', '2025-06-18 05:43:03', 2),
(2, 9, 2, 1, 'Pending', '2025-06-25 16:20:21', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `receiver`
--

DROP TABLE IF EXISTS `receiver`;
CREATE TABLE IF NOT EXISTS `receiver` (
  `receiver_id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_type_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `id_proof` varchar(255) DEFAULT NULL,
  `address_proof` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`receiver_id`),
  KEY `receiver_type_id` (`receiver_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receiver`
--

INSERT INTO `receiver` (`receiver_id`, `receiver_type_id`, `name`, `image`, `address`, `contact_no`, `id_proof`, `address_proof`, `description`, `status`, `email_id`, `password`) VALUES
(1, 3, 'Hope Children Shelter', '6849d055475f5_Hope_Children.jpg', 'No. 27, Jalan Seri Mawar 3\r\nTaman Bukit Indah\r\n81200 Johor Bahru, Johor\r\nMalaysia', '016-2345678', '6849d055479d2_1389224656304487500staff-id-card-500x500.jpg', '6849d05547d95_Hope_Children.jpg', 'Hope Children Shelter is a non-profit children\'s shelter located in the heart of Johor Bahru, Malaysia. Dedicated to providing a safe and nurturing environment, the shelter offers temporary housing, nutritious meals, education support, and emotional care for children in need. The home serves as a haven for orphans, abandoned children, and those from underprivileged or at-risk backgrounds. Staffed by compassionate caregivers and volunteers, Hope Children Shelter aims to empower each child with hope, stability, and the opportunity for a brighter future.', 'Active', 'hopechildren@gmail.com', '12345678'),
(2, 7, 'Mohamad Fadzal Bin Othman', '684e738d4b322_images.jpg', 'No. 22, Jalan Mawar 3, Taman Sri Muda, 40400 Shah Alam, Selangor', '0127754382', '684e738d4b94a_thumb.jpg', '684e738d4bf96_24846IMG-20200109-WA0001.jpg', 'Victim of recent flash flood in Taman Sri Muda, Shah Alam. Home and belongings were severely damaged. Currently staying at temporary relief center. Requires urgent assistance for food, clothing, and basic necessities.', 'Active', 'fadzal@gmail.com', '98765432'),
(4, 4, 'loh', '685bb2484c71c_11858cook.jpg', 'No. 12, Jalan SS2/24, 47300 Petaling Jaya, Selangor Darul Ehsan.', '0127754382', '685bb2484cf7b_1027620964orphanage.jpg', '685bb2484d5c3_6184535501027620964orphanage.jpg', 'ljijhhh', 'Active', 'sharundsouza@gmail.com', '98765432');

-- --------------------------------------------------------

--
-- Table structure for table `receiver_type`
--

DROP TABLE IF EXISTS `receiver_type`;
CREATE TABLE IF NOT EXISTS `receiver_type` (
  `receiver_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver_type` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`receiver_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receiver_type`
--

INSERT INTO `receiver_type` (`receiver_type_id`, `receiver_type`, `description`, `status`) VALUES
(1, 'Individual', 'Single person receiving donations', 'Active'),
(2, 'Family', 'Family unit receiving donations', 'Active'),
(3, 'Shelter', 'Homeless shelter or refuge center', 'Active'),
(4, 'Orphanage', 'Children\'s home or orphanage', 'Active'),
(5, 'School', 'Educational institution in need', 'Active'),
(6, 'Community Center', 'Local community support center', 'Active'),
(7, 'Disaster Victim', 'Person affected by natural disaster', 'Active'),
(8, 'Refugee', 'Person displaced from their home', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(10) NOT NULL AUTO_INCREMENT,
  `staff_type` varchar(20) NOT NULL,
  `staff_name` varchar(56) NOT NULL,
  `login_id` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_type`, `staff_name`, `login_id`, `password`, `status`) VALUES
(2, 'Admin', 'admin', 'admin', 'adminadminadmin', 'Active'),
(3, 'Admin', 'Anand Kumar', 'admin', 'admin', 'Active'),
(4, 'Employee ', 'arun ', 'karan', 'kkkk', 'Active');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `album`
--
ALTER TABLE `album`
  ADD CONSTRAINT `album_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `staff` (`staff_id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donor` (`donor_id`),
  ADD CONSTRAINT `items_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `item_categories` (`category_id`);

--
-- Constraints for table `item_requests`
--
ALTER TABLE `item_requests`
  ADD CONSTRAINT `item_requests_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  ADD CONSTRAINT `item_requests_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `donor` (`donor_id`),
  ADD CONSTRAINT `item_requests_ibfk_3` FOREIGN KEY (`processed_by`) REFERENCES `staff` (`staff_id`);

--
-- Constraints for table `receiver`
--
ALTER TABLE `receiver`
  ADD CONSTRAINT `receiver_ibfk_1` FOREIGN KEY (`receiver_type_id`) REFERENCES `receiver_type` (`receiver_type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
